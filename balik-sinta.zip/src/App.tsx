import React, { useState } from "react";

const Proposal: React.FC = () => {
  const [showFinalMessage, setShowFinalMessage] = useState(false);
  const [hovering, setHovering] = useState(false);

  const handleNoHover = () => {
    setHovering(!hovering);
  };

  const handleYesClick = () => {
    setShowFinalMessage(true);
    const audio = new Audio("https://www.example.com/song.mp3"); // Replace with your song URL
    audio.play();
  };

  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h1>Samahan mo ko sa Balik Sinta?</h1>
      {showFinalMessage ? (
        <div>
          <h2>Yay! Sama tayo!</h2>
          <img
            src="https://media.giphy.com/media/vtm4qejJIl1ERPIrbA/giphy.gif?cid=790b761161qbveksnfz3j3d8jybu4g8lo3najnw5i6i7tatv&ep=v1_gifs_search&rid=giphy.gif&ct=g" // Replace with your GIF URL
            alt="Kinikilig"
            style={{ width: "300px", height: "300px" }}
          />
          <audio controls autoPlay>
            <source src="https://www.example.com/song.mp3" type="audio/mpeg" />{" "}
            {/* Replace with the song URL */}
            Your browser does not support the audio element.
          </audio>
        </div>
      ) : (
        <div>
          <button
            style={{ margin: "10px", padding: "10px", fontSize: "18px" }}
            onClick={handleYesClick}
          >
            Oo
          </button>
          <button
            id="noButton"
            style={{
              margin: "10px",
              padding: "10px",
              fontSize: "18px",
              position: "relative",
            }}
            onMouseEnter={handleNoHover}
          >
            Hindi
          </button>
        </div>
      )}
    </div>
  );
};

export default Proposal;
